Terrain Engine Drivers
======================
A *Terrain Engine Driver* is a plugin that renders the osgEarth terrain.
In most cases, you should use the default - but legacy terrain engine plugins
are available to temporarily support uses that still need to transition to
the newest version of osgEarth.

.. toctree::
   :maxdepth: 1

   mp
   quadtree
